<p align="center">
    <a href="https://github.com/noob-kittu/YoneRobot/stargazers"><img src="https://img.shields.io/github/stars/noob-kittu/YoneRobot?label=Stars&style=flat-square&logo=github&color=F10070" alt="Stars" /></a>
</p>
<p align="center">
    <a href="https://github.com/noob-kittu/YoneRobot"> <img src="https://img.shields.io/github/repo-size/noob-kittu/YoneRobot?color=orange&logo=github&logoColor=green&style=for-the-badge" /></a>
    <a href="https://github.com/noob-kittu/YoneRobot/commits/prince"> <img src="https://img.shields.io/github/last-commit/noob-kittu/YoneRobot?color=blue&logo=github&logoColor=green&style=for-the-badge" /></a>
    <a href="https://github.com/noob-kittu/YoneRobot/issues"> <img src="https://img.shields.io/github/issues/noob-kittu/YoneRobot?color=blueviolet&logo=github&logoColor=green&style=for-the-badge" /></a>
    <a href="https://github.com/noob-kittu/YoneRobot/network/members"> <img src="https://img.shields.io/github/forks/noob-kittu/YoneRobot?color=red&logo=github&logoColor=green&style=for-the-badge" /></a>  
    <a href="https://pypi.org/project/Telethon/"> <img src="https://img.shields.io/pypi/v/telethon?color=yellow&label=telethon&logo=python&logoColor=green&style=for-the-badge" /></a>
</p>

<p align="center">
  <img src="https://telegra.ph/file/7e61fe06a9c02747249c4.jpg">
</p>

# YoneRobot
Me On Telegram [✨Yone✨](https://t.me/Yone_Robot)

## How To Host
The easiest way to deploy this Bot
<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/noob-kittu/YoneRobot"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>
 
CREDITS
```
Well, it's all in the commit history Feel free to open pull requests should any be missing.

```

<p align="center">
    <a href="//www.dmca.com/Protection/Status.aspx?ID=899e4481-3dc5-49f5-98f2-abf0e5d051b8" title="DMCA.com Protection Status" class="dmca-badge"> <img src="https://images.dmca.com/Badges/dmca_protected_sml_120n.png?ID=899e4481-3dc5-49f5-98f2-abf0e5d051b8"  alt="DMCA.com Protection Status" /></a>  
</p>
